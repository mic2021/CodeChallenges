﻿using System;

namespace ParsedSentence
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine(SentenceParser.Parsed("Smooth"));
        }
    }
}
