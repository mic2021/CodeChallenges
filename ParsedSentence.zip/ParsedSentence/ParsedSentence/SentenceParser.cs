﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
namespace ParsedSentence
{
    /// <summary>
    /// Parser Sentence Class
    /// </summary>
    public static class SentenceParser
    {
        /// <summary>
        /// Method to Parse a String
        /// </summary>
        /// <param name="sentence"></param>
        /// <returns></returns>
        public static string ParseString(string sentence)
        {
            var parse = BuildSentence(sentence);
            return parse;
        }

        /// <summary>
        /// Given a sentence split it by given delimiter
        /// </summary>
        /// <param name="sentence"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        private static string[] SplitSentence (string sentence, string pattern)
        {
           return Regex.Split(sentence, pattern);
        }

        /// <summary>
        /// Method to build a parsed sentence
        /// </summary>
        /// <param name="sentence"></param>
        /// <returns></returns>
        private static string BuildSentence(string sentence)
        {
            string parsed = string.Empty;
            List<WordType> words = new List<WordType>();
            if (!string.IsNullOrEmpty(sentence))
            {
                string pattern = "[a-zA-Z]+";
                var wordsspace = SplitSentence(sentence, " "); // split by space
                bool containsnotAlpha = false;
                
                // for each word splitted by space
                foreach (var item in wordsspace)
                {
                    var wordsItem = SplitSentence(item, pattern); // split by not alpha
                    containsnotAlpha = false;

                    // each word splitted by space and by not alpha
                    foreach (var itemPiece in wordsItem)
                    {
                        if (!string.IsNullOrEmpty(itemPiece)) // ignore empties entries
                        {
                            containsnotAlpha = true; // is an not alpha piece
                           
                            var wordstobuild = SplitSentence(item, itemPiece);
                            for (int index = 0; index < wordstobuild.Length; index++)
                            {
                                // insert in the middle not alpha separator to keep the order and then insert last word
                                if (index == wordstobuild.Length - 1)
                                {
                                   
                                    words.Add(new WordType(itemPiece, false));
                                    if (!string.IsNullOrEmpty(wordstobuild[index]))
                                        words.Add(new WordType(wordstobuild[index], true));

                                }
                                // insert first element
                                else
                                {
                                    if (!string.IsNullOrEmpty(wordstobuild[index]))
                                        words.Add(new WordType(wordstobuild[index], true));
                                }
                            }
                        }
                    }
                    if (!containsnotAlpha && !string.IsNullOrEmpty(item)) // the part not alpha is added without transform
                    {
                        words.Add(new WordType(item, true));
                    }
                }

                // call function to get first letter, count different letters in middle and last letter
                foreach (var item in words)
                {
                    if (!string.IsNullOrEmpty(parsed))
                    {
                        parsed = parsed + " " + GetParsedWord(item);
                    }
                    else
                    {
                        parsed = GetParsedWord(item);
                    }
                }
            }
            return parsed;
        }
      
        /// <summary>
        /// Method to parse a word getting first letter, number different letters between first and last and add the last if sentence is not alph then only add
        /// </summary>
        /// <param name="sentence"></param>
        /// <returns></returns>
        private static string GetParsedWord(WordType inputSentence)
        {
           
            var parsed = string.Empty;
            
            if (inputSentence.IsAlpha)
            {
                var firstLetter = string.Empty;
                var lastLetter = string.Empty;
                List<string> notrepeat = new List<string>();
                var letterValidate = string.Empty;
                var sentence = string.Empty;
                if (inputSentence.Word.Length > 1)
                {
                    firstLetter = inputSentence.Word.Substring(0, 1);
                lastLetter = inputSentence.Word.Substring(inputSentence.Word.Length - 1, 1);
              
                    sentence = inputSentence.Word.Substring(1, inputSentence.Word.Length - 2);
                    for (int index = 0; index <= sentence.Length - 1; index++)
                    {
                        if (index >= 0 && index <= sentence.Length - 1)
                        {
                            letterValidate = sentence.Substring(index, 1);
                            if (Regex.IsMatch(letterValidate, @"^[a-zA-Z]+$"))
                            {
                                if (!notrepeat.Contains(sentence.Substring(index, 1)))
                                {
                                    notrepeat.Add(sentence.Substring(index, 1));
                                }
                            }
                        }
                    }
                    parsed = firstLetter + notrepeat.Count + lastLetter;
                }
                else
                {
                    parsed = firstLetter + 0 + lastLetter;
                }
            }
            else
            {
                parsed = parsed + inputSentence.Word;
            }
                
            return parsed;
        }
    }
}
