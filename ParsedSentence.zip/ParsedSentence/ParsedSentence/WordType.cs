﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ParsedSentence
{
    public class WordType
    { 
        public string Word { get; set; }
        public bool IsAlpha { get; set; }
        public WordType (string word, bool isAlpha)
        {
            Word = word;
            IsAlpha = isAlpha;
        }
    }
}
