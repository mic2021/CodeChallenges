﻿using System;

namespace ParsedSentence
{
    class Program
    {
        static void Main(string[] args)
        {
           string input = "Hello";

            Console.WriteLine("Original Sentence: " + input);
            Console.WriteLine("Sentence Parsed: " + SentenceParser.ParseString(input));
            Console.ReadKey();
        }
    }
}
