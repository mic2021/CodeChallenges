﻿using System;

namespace ParsedSentence
{
    class Program
    {
        static void Main(string[] args)
        {
           string input = "Sign & ficant";

            Console.WriteLine("Original Sentence: " + input);
            Console.WriteLine("Sentence Parsed: " + SentenceParser.ParseString(input));
            Console.ReadKey();
        }
    }
}
